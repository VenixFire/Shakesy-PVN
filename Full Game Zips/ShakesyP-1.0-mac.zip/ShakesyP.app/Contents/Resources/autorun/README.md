
REWRITE:

  A downloadable distribution will be released by the end of the day, but if you don't want to wait you can follow these instructions to download the source code and run it yourself :)
  
  To install and play this video game prototype:
    
      Download and Install Ren'Py Visual Novel Engine v8.4.1: https://www.renpy.org 

      Once this is installed, move to your filesystem (Finder, if apple. File Explorer if windows)
      In your filesystem find where you installed Ren'Py, the default is usually downloads, but I like to install into Documents.

      Once you find the folder "renpy-8.4.1-sdk" you can download the code from this GitHub by clicking the "<> Code" Button and clicking Download ZIP. 

      Unzip the file from Downloads into the "renpy-8.4.1-sdk" folder. 

      Open Ren'py and look for the project on the left side of the screen. Click the project then click "Launch Project" in the bottom right corner.
